﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace GestionActivos.Models
{
    public class RolViewModel
    {
        public int Role_Id { get; set; }
        public string Role_Descripcion { get; set; }
        [NotMapped]
        public int scoop { get; set; }

        [NotMapped]
        public List<PantallaViewModel> pantallas { get; set; }

        [NotMapped]
        public List<int> PantallasID { get; set; }

        [NotMapped]
        public int Resultado { get; set; }

        [NotMapped]
        public string Nul { get; set; }
    }
}
