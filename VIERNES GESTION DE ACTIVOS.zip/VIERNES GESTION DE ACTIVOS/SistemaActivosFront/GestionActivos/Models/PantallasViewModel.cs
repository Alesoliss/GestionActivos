﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionActivos.Models
{
    public class PantallasViewModel
    {
        public int Pant_Id { get; set; }
        public string? Pant_Descripcion { get; set; }
    }
}
