﻿using GestionActivos.Models;
using GestionActivos.Servicios;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SistemaActivos.Common.Model;
using SistemasActivos.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace GestionActivos.Controllers
{
  
    public class RolController : Controller
    {
        public RolService _rolService;
        private readonly HttpClient _client;

        public RolController(RolService rolService, HttpClient client)
        {
            _client = client;

            _rolService = rolService;
        }

        [HttpGet("RolListado")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<IActionResult> Index()
        {
            try
            {
                var list = await _rolService.ObtenerRolList();
                return View(list.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpGet("CreatePantalla")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<IActionResult> Create()
        {
            try
            {
                var model = new List<PantallaViewModel>();
                var list = await _rolService.ObtenerPantallaList();
                return View(list.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpPost("CreatePantalla")]
        public async Task<IActionResult> Create(RolesViewModel item)
        {
            try
            {
                var list = await _rolService.CrearRoles(item);
                string[] notificaciones = new string[4];
                notificaciones[0] = "tim-icons icon-alert-circle-exc";
                notificaciones[1] = "Agregado";
                notificaciones[2] = "Se agregaron los datos con exito";
                notificaciones[3] = "info";
                TempData["Notificaciones"] = notificaciones;

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return View(item);
            }
        }

        [HttpGet("UpdateRol")]
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<IActionResult> Edit(int Rol_Id)
        {
            HttpContext.Session.SetString("rolll", Rol_Id.ToString());


            try
            {
                var apiUrl = "https://localhost:44311/API/Rol/UpdateRol?Rol_id=" + Rol_Id; 
                using (var httpClient = new HttpClient())
                {
                    var response = await httpClient.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        var content = await response.Content.ReadAsStringAsync();
                        var rolData = JsonConvert.DeserializeObject<RolViewModel>(content); 
                        return View(rolData);
                    }
                    else
                    {
                        return RedirectToAction("Error", "Home");
                    }
                }
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error", "Home");
            }
        }


        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Delete([FromForm] int Rol_Id)
        //{
        //    try
        //    {
        //        var list = await _rolService.EliminarRol(Rol_Id);
        //        var hola = list.Message;
        //        if (hola == "Error al realizar la operacion.")
        //        {
        //            string[] notificaciones = new string[4];
        //            notificaciones[0] = "tim-icons icon-alert-circle-exc";
        //            notificaciones[1] = "Error";
        //            notificaciones[2] = "Ocurrio un error al eliminar el rol";
        //            notificaciones[3] = "danger";
        //            TempData["Notificaciones"] = notificaciones;
        //        }
        //        else
        //        {
        //            string[] notificaciones = new string[4];
        //            notificaciones[0] = "tim-icons icon-alert-circle-exc";  
        //            notificaciones[1] = "Exito";
        //            notificaciones[2] = "Se elimino el rol con exito";
        //            notificaciones[3] = "info";
        //            TempData["Notificaciones"] = notificaciones;
        //        }
        //        return RedirectToAction("Index");
        //    }
        //    catch (Exception ex)
        //    {
        //        return RedirectToAction("Index");
        //    }
        //}




        public async Task<IActionResult> Master(RolesViewModel rol)
        {
            var response = await _client.GetAsync($"​/API​/Rol​/Master​/Activos?Role_Id={rol.Role_Id}");

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var jsonObject = JsonConvert.DeserializeObject<JObject>(content);
                var data = jsonObject["data"].ToString();
                var departamentos = JsonConvert.DeserializeObject<IEnumerable<RolesViewModel>>(data);
                return View(departamentos);
            }
            else
            {
                return View("Error");
            }
        }


        [HttpPost]
        public async Task<IActionResult> Delete(RolesViewModel item, int Role_id)
        {

            var list = await _rolService.EliminadoRol(item, Role_id);
            if (list.Success)
            {
                TempData["Exito"] = "El Rol se agrego con exito";
                return RedirectToAction("Index");
            }
            else
            {
                TempData["Error"] = "El Rol no se pudo agregar";
                return RedirectToAction("Index");

            }
        }

    }
}
