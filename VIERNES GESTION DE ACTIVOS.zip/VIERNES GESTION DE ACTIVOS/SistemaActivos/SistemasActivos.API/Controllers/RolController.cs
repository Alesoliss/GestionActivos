﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using SistemaActivos.Entities.Entities;
using SistemaDeActivos.BusinessLogic.Services;
using SistemasActivos.API.Clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SistemaActivos.Common.Model;

namespace SistemasActivos.API.Controllers
{
    [ApiController]
    [Route("/API/[controller]")]
    public class RolController : Controller
    {
        private readonly AccesoService _accesoServices;
        private readonly IMapper _mapper;

        public RolController(AccesoService accesoServices, IMapper mapper)
        {
            _accesoServices = accesoServices;
            _mapper = mapper;
        }

        [HttpGet("ListadoRoles")]
        public IActionResult Index()
        {
            var list = _accesoServices.ListRol();
            return Ok(list);
        }

        [HttpGet("ValidarUrl")]
        public IActionResult ValidarUrl(int Pant_Id, int Rol_Id)
        {
            var list = _accesoServices.ValidarUrl(Pant_Id, Rol_Id);
            return Ok(list);
        }

        [HttpGet("CreatePantalla")]
        public IActionResult Create()
        {
            var list = _accesoServices.ListPantalla();
            return Ok(list);
        }

        [HttpPost("CreatePantalla")]
        public IActionResult Create([FromBody] FormData formData)
        {
            string txtRol = formData.txtRol;

            var r = _accesoServices.ObtenerRol(txtRol);
            var rr = r.Data as IEnumerable<tbRoles>;

            if (rr.ToList().Count > 0)
            {
                return RedirectToAction("https://localhost:44346/CreatePantalla");
            }

            else
            {
                List<int> pantallasSeleccionadas = formData.pantallasSeleccionadas;

                try
                {

                    var modelo = new tbRoles()
                    {
                        Role_Descripcion = txtRol,
                        Role_UsuarionCreacion = 1, 
                        Role_FechaCreacion = DateTime.Now
                    };

                    var list = _accesoServices.InsertarRol(modelo);

                    var id = _accesoServices.ObtenerId(modelo.Role_UsuarionCreacion, modelo.Role_FechaCreacion);

                    var rol = id.Data;

                    int rolid = 0;

                    foreach (var item in rol)
                    {
                        rolid = item.Role_Id;
                    }

                    foreach (var pantalla in pantallasSeleccionadas)
                    {
                        var modelo2 = new tbPantallasPorRoles()
                        {
                            Pant_Id = pantalla,
                            Role_Id = rolid,
                            PaRo_UsuarioCreacion = 1,
                            PaRo_FechaCreacion = DateTime.Now
                        };

                        var msj = _accesoServices.InsertarPantallasPorRol(modelo2);
                    }
                    return Ok(list);
                }
                catch
                {

                    return Ok();

                }
            }
        }

        [HttpGet("UpdateRol")]
        public IActionResult Update(int Rol_id)
        {
            var PantallasPorRol = _accesoServices.ObtenerPantallasPorRol(Rol_id);
            var Pantallas = _accesoServices.ListPantalla();
            var ObtenerRol = _accesoServices.ObtenerRol(Rol_id);

            int rolid = 0;
            string NombreRol = "";

            var Rol = ObtenerRol.Data;

            foreach (var item in Rol)
            {
                rolid = item.Role_Id;
                NombreRol = item.Role_Descripcion;
            }

            var pantallasSeleccionadas = PantallasPorRol.Select(p => (int)p.Pant_Id).ToList();

            var panta = Pantallas.Data as IEnumerable<tbPantallas>;

            var pantallasViewModel = _mapper.Map<List<PantallaViewModel>>(panta);

            var rolViewModel = new RolesViewModel
            {
                Role_Id = rolid,
                Role_Descripcion = NombreRol,
                PantallasID = pantallasSeleccionadas,
                pantallas = (List<PantallaViewModel>)pantallasViewModel,
            };
            return Ok(rolViewModel);
        }

        [HttpPost("UpdateRol")]
        public JsonResult Edit([FromBody] FormData formData)
        {
            if (string.IsNullOrEmpty(formData.txtRol))
            {
                ModelState.AddModelError("txtRol", "El nombre del rol es requerido.");
            }

            var rol = new tbRoles()
            {
                Role_Id = formData.Rol_Id,
                Role_Descripcion = formData.txtRol,
                Role_UsuarioModificacion = 1, 
                Role_FechaModificacion = DateTime.Now,

            };

            var id = _accesoServices.ObtenerId((int)rol.Role_UsuarioModificacion, (DateTime)rol.Role_FechaModificacion);
            var role = id.Data as IEnumerable<tbRoles>;

            var Rol = new tbRoles()
            {
                Role_Id = formData.Rol_Id,
                Role_Descripcion = formData.txtRol,
                Role_UsuarioModificacion = 1, 
                Role_FechaModificacion = DateTime.Now,

            };

            _accesoServices.ActualizarRol(Rol);
            _accesoServices.EliminarPantallaPorRol(formData.Rol_Id);


            foreach (var pantalla in formData.pantallasSeleccionadas)
            {
                var modelo2 = new tbPantallasPorRoles()
                {
                    Pant_Id = pantalla,
                    Role_Id = formData.Rol_Id,
                    PaRo_UsuarioCreacion = 1,
                    PaRo_FechaCreacion = DateTime.Now
                };

                var msj = _accesoServices.InsertarPantallasPorRol(modelo2);
            }

            return Json(1);

        }

        [HttpDelete("DeleteRol")]
        public IActionResult Delete(int Rol_id)
        {
            _accesoServices.EliminarPantallaPorRol(Rol_id);
            var list = _accesoServices.EliminarRol(Rol_id);
            return Ok(list);
        }




        [HttpGet("Master/Activos")]
        public IActionResult MasterRoles(int Rol_id)
        {
            var list = _accesoServices.ObtenerPantallasPorIdRol(Rol_id);

            return Ok(list);
        }




        [HttpDelete("Eliminado/{Role_id}")]
        public IActionResult EliminadoRol(int Role_id)
        {

            var list = _accesoServices.EliminadoRol(Role_id);

            if (list.Success)
            {
                return Ok(list);
            }
            else
            {
                return Problem(list.Message);
            }

        }






    }
}
