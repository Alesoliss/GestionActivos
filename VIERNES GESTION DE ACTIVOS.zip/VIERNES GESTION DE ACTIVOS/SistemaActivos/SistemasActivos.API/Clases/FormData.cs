﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace SistemasActivos.API.Clases
{
    public class FormData
    {
        public int Rol_Id { get; set; }
        [Required(ErrorMessage = "El Campo {0} es requerido")]

        public string txtRol { get; set; }
        public List<int> pantallasSeleccionadas { get; set; }
    }
}
