﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaActivos.Common.Model
{
  public  class PantallaViewModel
    {
        public int Pant_Id { get; set; }
        public string Pant_Descripcion { get; set; }

        [NotMapped]
        public List<int> PantallasID { get; set; }

        [NotMapped]
        public int numero { get; set; }

        [NotMapped]
        public int pantID { get; set; }
        [NotMapped]

        public string pantDescripcion { get; set; }
    }
}
