﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaActivos.Common.Model
{
    public class PantallasViewModel
    {
        public int Pant_Id { get; set; }
        public string Pant_Descripcion { get; set; }
    }
}

