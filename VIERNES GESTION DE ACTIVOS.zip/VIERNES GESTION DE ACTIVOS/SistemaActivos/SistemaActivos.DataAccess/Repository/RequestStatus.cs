﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AHM.Total.Travel.DataAccess.Repositories
{
    public class RequestStatus
    {
        public int CodeStatus { get; set; }
        public string MessageStatus { get; set; }
    }
}
