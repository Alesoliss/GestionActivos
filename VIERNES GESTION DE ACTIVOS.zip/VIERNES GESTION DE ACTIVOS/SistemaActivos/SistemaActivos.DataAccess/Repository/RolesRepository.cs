﻿using AHM.Total.Travel.DataAccess.Repositories;
using Dapper;
using Microsoft.Data.SqlClient;
using SistemaActivos.Entities.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaActivos.DataAccess.Repository
{
    public class RolesRepository : IRepository<tbRoles>
    {
        public RequestStatus EliminarRol(int Rol_Id)
        {
            string sql = ScriptDataBase.Rol_Eliminar;
            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parametro = new DynamicParameters();
                parametro.Add("@Rol_Id", Rol_Id);

                var result = db.Execute(
                    sql, parametro,
                    commandType: CommandType.StoredProcedure
                );

                string mensaje = (result == 1) ? "exito" : "error";

                return new RequestStatus { CodeStatus = result, MessageStatus = mensaje };

            };
        }

        public RequestStatus EliminarPantallaPorRol(int PaRo_Id)
        {
            string sql = ScriptDataBase.PanRo_Eliminar;
            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parametro = new DynamicParameters();
                parametro.Add("@PaRo_Id", PaRo_Id);

                var result = db.Execute(
                    sql, parametro,
                    commandType: CommandType.StoredProcedure
                );

                string mensaje = (result == 1) ? "exito" : "error";

                return new RequestStatus { CodeStatus = result, MessageStatus = mensaje };

            };
        }

        public tbRoles Details(int? id)
        {
            throw new NotImplementedException();
        }

        public tbRoles find(int? id)
        {
            throw new NotImplementedException();
        }

        public RequestStatus InsertPantallasRoles(tbPantallasPorRoles item)
        {
            string sql = ScriptDataBase.PanRo_Insertar;

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parameter = new DynamicParameters();
                parameter.Add("@Rol_Id", item.Role_Id);
                parameter.Add("@Pant_Id", item.Pant_Id);
                parameter.Add("@PaRo_Creacion", item.PaRo_UsuarioCreacion);
                parameter.Add("@PaRo_FechaCreacion", item.PaRo_FechaCreacion);

                var result = db.Execute(sql, parameter, commandType: CommandType.StoredProcedure);
                string mensaje = (result == 1) ? "exito" : "error";
                return new RequestStatus { CodeStatus = result, MessageStatus = mensaje };

                //var result = db.QueryFirst(sql, parameter, commandType: CommandType.Text);

                //return result;
            }
        }

        public RequestStatus Insert(tbRoles item)
        {
            string sql = ScriptDataBase.Rol_Insertar;

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parameter = new DynamicParameters();
                parameter.Add("@Rol_Descripcion", item.Role_Descripcion);
                parameter.Add("@Rol_Creacion", item.Role_UsuarionCreacion);
                parameter.Add("@Rol_FechaCreacion", item.Role_FechaCreacion);

                var result = db.Execute(sql, parameter, commandType: CommandType.StoredProcedure);
                string mensaje = (result == 1) ? "exito" : "error";
                return new RequestStatus { CodeStatus = result, MessageStatus = mensaje };
            }
        }


        public IEnumerable<tbRoles> List()
        {
            string sql = ScriptDataBase.Rol_Listar;

            List<tbRoles> result = new List<tbRoles>();

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                result = db.Query<tbRoles>(sql, commandType: CommandType.Text).ToList();

                return result;
            }
        }

        public IEnumerable<tbRoles> ValidarUrl(int Pant_Id, int Rol_Id)
        {
            string sql = ScriptDataBase.Validar_Url;

            List<tbRoles> result = new List<tbRoles>();

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parameters = new { Pant_Id, Rol_Id };
                result = db.Query<tbRoles>(sql, parameters, commandType: CommandType.StoredProcedure).ToList();
                return result;
            }
        }

        public IEnumerable<tbRoles> findObtenerId(int usuario_creacion, DateTime fecha_creacion)
        {
            string sql = ScriptDataBase.Rol_ObtenerId;

            List<tbRoles> result = new List<tbRoles>();

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parameters = new { usuario_creacion, fecha_creacion };
                result = db.Query<tbRoles>(sql, parameters, commandType: CommandType.StoredProcedure).ToList();
                return result;
            }
        }

        public IEnumerable<tbRoles> ObtenerRol(string Rol_Descripcion)
        {
            string sql = ScriptDataBase.Rol_Obtener_Rol;

            List<tbRoles> result = new List<tbRoles>();

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parameters = new { Rol_Descripcion };
                result = db.Query<tbRoles>(sql, parameters, commandType: CommandType.StoredProcedure).ToList();
                return result;
            }
        }

        public IEnumerable<tbPantallasPorRoles> ObtenerRol(int Rol_Id)
        {
            string sql = ScriptDataBase.Rol_Obtener;

            List<tbPantallasPorRoles> result = new List<tbPantallasPorRoles>();

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parameters = new { Rol_Id = Rol_Id };
                result = db.Query<tbPantallasPorRoles>(sql, parameters, commandType: CommandType.StoredProcedure).ToList();
                return result;
            }
        }

        public IEnumerable<tbPantallasPorRoles> BuscarPantallasPorRol(int Rol_Id)
        {
            string sql = ScriptDataBase.PanRo_Buscar;

            List<tbPantallasPorRoles> result = new List<tbPantallasPorRoles>();

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parameters = new { Rol_Id = Rol_Id };
                result = db.Query<tbPantallasPorRoles>(sql, parameters, commandType: CommandType.StoredProcedure).ToList();
                return result;
            }
        }
        public RequestStatus Update(tbRoles item)
        {
            string sql = ScriptDataBase.Rol_Actualizar;

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parameter = new DynamicParameters();
                parameter.Add("@Rol_Id", item.Role_Id);
                parameter.Add("@Rol_Descripcion", item.Role_Descripcion);
                parameter.Add("@Rol_Modificacion", item.Role_UsuarioModificacion);
                parameter.Add("@Rol_FechaModificacion", item.Role_FechaModificacion);

                var result = db.Execute(sql, parameter, commandType: CommandType.StoredProcedure);

                string mensaje = (result > 0) ? "exito" : "error";
                return new RequestStatus { CodeStatus = result, MessageStatus = mensaje };
            }

            //throw new NotImplementedException();
        }



     


        //agrgarr
        public IEnumerable<tbPantallas> ObtenerPantallasPorRol(int RolId)
        {
            string sql = "Acce.SP_ObtenerPantallasPorRol";
            List<tbPantallas> result = new List<tbPantallas>();

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parameters = new { RolId };
                result = db.Query<tbPantallas>(sql, parameters, commandType: CommandType.StoredProcedure).ToList();
                return result;
            }
            
        }


        public RequestStatus EliminadoRol(int id)
        {
            string sql = ScriptDataBase.Rol_Eliminado;

            using (var db = new SqlConnection(SistemaActivosContext.ConnectionString))
            {
                var parametro = new DynamicParameters();
                parametro.Add("Role_Id", id);
                var result = db.Execute(sql, parametro, commandType: CommandType.StoredProcedure);

                return new RequestStatus { CodeStatus = result, MessageStatus = "" };

            }
        }


        public RequestStatus Delete(int? id)
        {
            throw new NotImplementedException();
        }

        public tbRoles Find(int? id)
        {
            throw new NotImplementedException();
        }

    }
}
