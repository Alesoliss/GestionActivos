﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaActivos.Common.Model
{
   public class VidaUtilViewmodel
    {

        public int VidU_Id { get; set; }
        public int? Cate_Id { get; set; }
        public string VidU_Descripcion { get; set; }
        public decimal? VidU_VidaEstimada { get; set; }
        public int? VidU_UsuarioCreacion { get; set; }
        public DateTime? VidU_FechaCreacion { get; set; }
        public int? VidU_UsuarioModificacion { get; set; }
        public DateTime? VidU_FechaModificacion { get; set; }
        public bool? VidU_Estado { get; set; }
    }
}
