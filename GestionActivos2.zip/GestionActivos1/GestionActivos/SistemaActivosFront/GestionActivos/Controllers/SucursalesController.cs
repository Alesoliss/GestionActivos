﻿using GestionActivos.Models;
using GestionActivos.Servicios;
using Microsoft.AspNetCore.Mvc;
using SistemasActivos.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionActivos.Controllers
{
    public class SucursalesController : Controller
    {
        public SucursalesServices _sucursalesServices;
        public SucursalesController(SucursalesServices sucursalesServices)
        {
            _sucursalesServices = sucursalesServices;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var model = new List<SucursalesViewModel>();
                var list = await _sucursalesServices.ObtenerSucursalesList();
                return View(list.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Index", "Home");
            }
        }
    }
}
