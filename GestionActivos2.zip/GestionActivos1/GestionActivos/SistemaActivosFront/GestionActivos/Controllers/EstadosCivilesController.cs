﻿using GestionActivos.Models;
using GestionActivos.Servicios;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionActivos.Controllers
{
    public class EstadosCivilesController : Controller
    {
        public EstadosCivilesServices _estadosCivilesServices;
        public EstadosCivilesController(EstadosCivilesServices estadosCivilesServices)
        {
            _estadosCivilesServices = estadosCivilesServices;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var model = new List<EstadosCivilesViewModel>();
                var list = await _estadosCivilesServices.ObtenerEstadosCivilesList();
                return View(list.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Index", "Home");
            }
        }
    }
}
