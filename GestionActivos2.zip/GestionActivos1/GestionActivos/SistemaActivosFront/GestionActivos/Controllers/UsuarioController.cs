﻿using GestionActivos.Servicios;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SistemaActivos.Common.Model;
using SistemasActivos.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace GestionActivos.Controllers
{
    public class UsuarioController : Controller
    {
        public UsuariosService _usuariosService;
        public UsuarioController(UsuariosService usuariosService)
        {
            _usuariosService = usuariosService;
        }
        // GET: UsuarioController
        public async Task<IActionResult> Index()
        {
            try
            {
                var model = new List<UsuariosViewmodel>();
                var list = await _usuariosService.ObtenerUsuariosList();
                return View(list.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public ActionResult Create()
        {
            return View();
        }

        // POST: DepartamentosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(UsuariosViewmodel item)
        {
            try
            {
                item.Usua_UsuarionCreacion = 1;
                item.Usua_FechaCreacion = DateTime.Now;
                var list = await _usuariosService.CrearUsuario(item);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return View(item);
            }
        }



        [HttpGet("usuarios/llenar/{Usua_Id}")]
        public async Task<IActionResult> llenar(UsuariosViewmodel item, int Usua_Id)
        {
            try
            {
                var list = await _usuariosService.LlenarUsuario(Usua_Id);
                return View(list.Data);
            }
            catch (Exception ex)
            {
                return View(item);
            }
        }



        [HttpPost]
        public async Task<IActionResult> Update(UsuariosViewmodel item)
        {
            try
            {
                item.Usua_UsuarionModificacion = 1;
                item.Usua_FechaModificacion = DateTime.Now;
                var list = await _usuariosService.ActualizarUsuario(item);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return View(item);
            }
        }


        [HttpPost]
        public IActionResult Delete(UsuariosViewmodel item, int Usua_Id)
        {
            try
            {
                var list = _usuariosService.EliminarUsuario(item, Usua_Id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View(item);
            }
        }

        //GET: DepartamentosController/Details
        public async Task<IActionResult> Details(string Usua_Id, UsuariosViewmodel item)
        {
            var list = await _usuariosService.DetallesUsuario(Usua_Id);
            if (list.Success)

            {
                try
                {

                    var data = list.Data;

                    return View(data);
                }
                catch (Exception ex)
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                return View("Error");
            }
        }
    }
}
