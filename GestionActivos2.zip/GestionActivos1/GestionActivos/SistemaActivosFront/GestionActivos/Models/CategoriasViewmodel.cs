﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace SistemasActivos.API.Model
{
   public class CategoriasViewmodel
    {
        public int Cate_Id { get; set; }
        public string Cate_Descripcion { get; set; }
        public int? Cate_UsuarioCreacion { get; set; }
        public DateTime? Cate_FechaCreacion { get; set; }
        public int? Cate_UsuarioModificacion { get; set; }
        public DateTime? Cate_FechaModificacion { get; set; }
        public bool? Cate_Estado { get; set; }

     
    }
}
