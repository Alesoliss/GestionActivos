﻿using GestionActivos.Models;
using GestionActivos.WebAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionActivos.Servicios
{
    public class SucursalesServices
    {
        private readonly API _api;

        public SucursalesServices(API api)
        {
            _api = api;
        }

        public async Task<ServiceResult> ObtenerSucursalesList()
        {
            var result = new ServiceResult();
            try
            {
                var response = await _api.Get<IEnumerable<SucursalesViewModel>, IEnumerable<SucursalesViewModel>>(req =>
                {
                    req.Path = $"/API/Sucursales/Listado";
                });
                if (!response.Success)
                {
                    return result.FromApi(response);
                }
                else
                {
                    return result.Ok(response.Data);
                }
            }
            catch (Exception ex)
            {
                return result.Error(Helpers.GetMessage(ex));
                throw;
            }
        }
    }
}
