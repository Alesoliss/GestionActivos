﻿using GestionActivos.Models;
using GestionActivos.Servicios;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionActivos.Controllers
{
    public class EstadosCivilesController : Controller
    {
        public EstadosCivilesServices _estadosCivilesServices;
        public EstadosCivilesController(EstadosCivilesServices estadosCivilesServices)
        {
            _estadosCivilesServices = estadosCivilesServices;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var model = new List<EstadosCivilesViewModel>();
                var list = await _estadosCivilesServices.ObtenerEstadosCivilesList();
                return View(list.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Index", "Home");
            }
        }

       

        [HttpPost]
        public async Task<IActionResult> Update(EstadosCivilesViewModel item)
        {
            try
            {
                item.EstD_UsuarioModificacion = 1;
                item.EstD_FechaModificacion = DateTime.Now;
                var list = await _estadosCivilesServices.ActualizarEstadoCivil(item);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return View(item);
            }
        }

        [HttpPost]
        public IActionResult Delete(EstadosCivilesViewModel item, int EstD_Id)
        {
            try
            {
                var list = _estadosCivilesServices.EliminarEstado(item, EstD_Id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View(item);
            }
        }
    }
}
