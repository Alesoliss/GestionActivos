﻿using GestionActivos.Models;
using GestionActivos.Servicios;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionActivos.Controllers
{
    public class Empleados1Controller : Controller
    {
        private readonly EmpleadoServicio _empleadoServicio;

        public Empleados1Controller(EmpleadoServicio empleadoServicio)
        {
            _empleadoServicio = empleadoServicio;
        }
        public async Task<IActionResult> Index()
        {
            try
            {
                var model = new List<EmpleadosViewmodel>();
                var list = await _empleadoServicio.ObtenerCategoriaList();
                return View(list.Data);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Index", "Home");
            }
        }
    }
}
